﻿EMBED_MODEL_PATH = './AI-ModelScope/bge-small-zh-v1___5'
MODEL_PATH = './IEITYuan/Yuan2-2B-Mars-hf'